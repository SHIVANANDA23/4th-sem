#include <stdio.h>

int main() {
    int m;
    scanf ("%d",m);
  printf("Hello, world!\n");
  return 0;
}
