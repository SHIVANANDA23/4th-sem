#include<stdio.h>
void rec(int n)
{
    if(n>0)
    {

        for(int i=1; i<n; i=i*2)
        {
            printf("%d ",n);
        }
        rec(n-1);
    }
}
int main()
{
    FILE* fp=fopen("Mohit.txt","w");
    char a[100];
    for(int i=0; i<0; i++)
    {
        scanf("%s",a);
        fprintf(fp,"%s\n",a);
    }
    fclose(fp);
    rec(10);
    return 0;
}
