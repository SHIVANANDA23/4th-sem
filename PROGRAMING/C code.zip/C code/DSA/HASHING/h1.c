#include<stdio.h>
int hashing(int r)
{
    return r%10;
}
void  call(int a[10])
{int m;
    printf("Enter the number u want to search\n");
    scanf("%d",&m);
   if(a[hashing(m)]==m)
   {
       printf("Number %d is found at %d \n",m,hashing(m));
   }
   else
   {
       printf("Number %d is not found\n",m);
   }
}

int main()
{
    int a[10],n,m,i;
    printf("Enter the numbers\n");
    for(i=0;i<10;i++)
    {
        scanf("%d",&m);
        printf("\n");
        a[hashing(m)]=m;
    }
   call(a);
}
