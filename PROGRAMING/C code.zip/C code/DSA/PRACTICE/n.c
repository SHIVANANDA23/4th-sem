#include <stdio.h>
#include <stdlib.h>

void BinarySearch(int *arr, int f, int l, int key);

int main()
{
    int arr[] = {10, 15, 25, 47, 84, 147, 54, 652, 201, 14, 78, 96, 32};
    int m = sizeof(arr) / sizeof(arr[0]);
    BinarySearch(arr, 0, m, 54);
    return 0;
}

void BinarySearch(int *arr, int f, int l, int key)
{
    if (l >= f)
    {
        int mid = f + (l - f) / 2;

        if (arr[mid] == key)
        {
            printf("ELEMENT IS AT %d\n", mid);
            arr[mid] = 20000;
            return;
        }
        else if (arr[mid] > key)
        {
            BinarySearch(arr, f, mid - 1, key);
        }
        else
        {
            BinarySearch(arr, mid + 1, l, key);
        }
    }
    else
    {
        printf("The %d is not present in the array you entered.\n", key);
    }
}

