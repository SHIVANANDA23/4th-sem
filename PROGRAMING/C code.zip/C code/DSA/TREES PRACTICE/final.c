#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

struct node {
    char name[10];
    int numc;
    struct node* next;
    struct node* prev;
};

struct node* create_node() {
    struct node* newn = (struct node*)malloc(sizeof(struct node));
    if (newn == NULL) {
        printf("Memory not allocated");
    } else {
        scanf("%s%d", newn->name, &newn->numc);
        newn->next = NULL;
        newn->prev = NULL;
    }
    return newn;
}

struct node* insert_end(struct node* head) {
    struct node* cur = NULL;
    struct node* newn = create_node();
    if (head == NULL) {
        head = newn;
    } else {
        cur = head;
        while (cur->next != NULL) {
            cur = cur->next;
        }
        cur->next = newn;
        newn->prev = cur;
    }
    return head;
}

void remaining_candies(struct node* head, int D) {
    struct node* alice = head;
    struct node* bob = NULL;
    int alice_candies = 0;
    int bob_candies = 0;

    // Move alice to the Dth jar from the left
    for (int i = 0; i < D && alice != NULL; i++) {
        alice_candies += alice->numc;
        alice = alice->next;
    }

    if (alice != NULL)
        bob = alice->prev;

    // Move bob to the Dth jar from the right
    while (bob != NULL && bob->prev != NULL && D > 0) {
        bob_candies += bob->numc;
        bob = bob->prev;
        D--;
    }

    printf("Remaining candies after Alice's turn:\n");
    struct node* cur = head;
    while (cur != alice) {
        printf("%s: %d\n", cur->name, cur->numc);
        cur = cur->next;
    }
    printf("\n");

    printf("Remaining candies after Bob's turn:\n");
    while (cur != NULL) {
        printf("%s: %d\n", cur->name, cur->numc);
        cur = cur->next;
    }
    printf("\n");

    printf("Total remaining candies in the jars: %d\n", alice_candies + bob_candies);
}

int main() {
    struct node* head = NULL;
    int n, D;
    printf("Enter the total number of jars: ");
    scanf("%d", &n);

    printf("Enter the name and number of candies for each jar:\n");
    for (int i = 0; i < n; i++)
        head = insert_end(head);

    printf("Enter the number of candies Alice and Bob will eat (D): ");
    scanf("%d", &D);

    printf("After eating candies:\n");
    remaining_candies(head, D);

    return 0;
}
