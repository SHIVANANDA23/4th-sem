#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TABLE_SIZE 100

// Structure for a dictionary word
struct Word {
    char word[50];
};

// Hash table using linear probing
struct Word hashTable[TABLE_SIZE];

// Function to calculate the hash value for a word
int hashFunction(char* word) {
    int len = strlen(word);
    int hash = 0, i;

    for (i = 0; i < len; i++) {
        hash += word[i];
    }

    return hash % TABLE_SIZE;
}

// Function to insert a word into the hash table
void insertWord(char* word) {
    int hash = hashFunction(word);

    while (hashTable[hash].word[0] != '\0') {
        // Move to the next slot using linear probing
        hash = (hash + 1) % TABLE_SIZE;
    }

    strcpy(hashTable[hash].word, word);
}

// Function to check if a word is present in the hash table
int Word_presence(char* word) {
    int hash = hashFunction(word);
    int initialHash = hash;

    while (hashTable[hash].word[0] != '\0') {
        if (strcmp(hashTable[hash].word, word) == 0) {
            return 1; // Word found in the hash table
        }

        // Move to the next slot using linear probing
        hash = (hash + 1) % TABLE_SIZE;

        // If we have checked all slots and reached the initial hash value, the word is not present
        if (hash == initialHash) {
            return 0;
        }
    }

    return 0; // Word not found in the hash table
}

int main() {
    // Initialize the hash table
    for (int i = 0; i < TABLE_SIZE; i++) {
        hashTable[i].word[0] = '\0';
    }
FILE *fp=fopen("hash.txt","r");
for(int i=0;i<6;i++)
{
    fp=fscanf(fp,"%s",arr);
    insertWord(arr[50]);

}
    // Perform spell-checking
    char word[50];

    printf("Enter a word to check its spelling: ");
    scanf("%s", word);

    if (Word_presence(word)) {
        printf("The word is spelled correctly.\n");
    } else {
        printf("The word is misspelled.\n");
    }

    return 0;
}
