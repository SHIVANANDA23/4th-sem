#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Size of the hash table
#define TABLE_SIZE 100

// Structure for a symbol entry
struct SymbolEntry {
    char symbol[50];
    int address;
};

// Hash table using quadratic probing
struct SymbolEntry hashTable[TABLE_SIZE];

// Function to calculate the hash value for a symbol
int hashFunction(char* symbol) {
    int len = strlen(symbol);
    int hash = 0, i;

    for (i = 0; i < len; i++) {
        hash += symbol[i];
    }

    return hash % TABLE_SIZE;
}

// Function to insert a symbol into the hash table
void insertSymbol(char* symbol, int address) {
    int hash = hashFunction(symbol);
    int i = 1;

    while (hashTable[hash].symbol[0] != '\0') {
        // Move to the next slot using quadratic probing
        hash = (hash + i * i) % TABLE_SIZE;
        i++;
    }

    strcpy(hashTable[hash].symbol, symbol);
    hashTable[hash].address = address;
}

// Function to find the address of a symbol in the hash table
int findSymbol(char* symbol) {
    int hash = hashFunction(symbol);
    int initialHash = hash;
    int i = 1;

    while (hashTable[hash].symbol[0] != '\0') {
        if (strcmp(hashTable[hash].symbol, symbol) == 0) {
            return hashTable[hash].address;
        }

        // Move to the next slot using quadratic probing
        hash = (hash + i * i) % TABLE_SIZE;
        i++;

        // If we have checked all slots and reached the initial hash value, the symbol is not present
        if (hash == initialHash) {
            return -1;
        }
    }

    return -1;
}

int main() {
    // Initialize the hash table
    for (int i = 0; i < TABLE_SIZE; i++) {
        hashTable[i].symbol[0] = '\0';
        hashTable[i].address = -1;
    }
  int n;
    // Insert symbols into the hash table
 FILE *fp=fopen("read.txt","r");
 for (int i = 0; i < 4; i++)
 {
    fscanf(fp,"%s %d",arr,&n);
    insertSymbol(arr, n);
 }

    // Find the address of a symbol
    char symbol[50],arr[50];
    printf("Enter the symbol to find its address: ");
    scanf("%s", symbol);

    int address = findSymbol(symbol);

    if (address != -1) {
        printf("The address of %s is %d.\n", symbol, address);
    } else {
        printf("The symbol %s is not found.\n", symbol);
    }

    return 0;
}
