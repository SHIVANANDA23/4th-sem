#include<lpc21xx.h>
void cmd(unsigned char a);
void data(unsigned char b);
void delay(unsigned int c);

int main()
{
    unsigned char data1[]={"HELLO MAN"};
    unsigned char cmd1[]={0x30,0x30,0x20,0x20,0x28,0x28,0x01,0x06,0x0e,0x80}
    unsigned int i,j;
    IODIR0=0X000000FC;
    for(i=0;i<10;i++)
    {
        cmd(cmd1[i]);
        delay(2000);
    }
    while(1)
    {
        cmd(0x80);
        delay(2000);
        for(j=0;j<11;j++)
        {
            data(data1[j]);
            delay(2000);
        }
        delay(2000);
        cmd(0x01);
        delay(20000);
    }
}
void cmd(unsigned char a)
{
    unsigned int m,n;
    n=a;
    n=n&0xf0;
    IOCLR0=0X000000FC;
    IOCLR0=0X00000004;
    IOSET0=N;
    IOSET0=0X08;
    delay(20);
    IOCLR0=0X08;
    m=a;
    m=m&0x0f;
    m=m<<4;
    IOCLR0=0XFC;
    IOCLR0=0X4;
    IOSET0=M;
    IOSET0=0X8;
    DELAY(20);
    IOCLR0=0X8;
}
void cmd(unsigned char a)
{
    unsigned int m,n;
    n=a;
    n=n&0xf0;
    IOCLR0=0X000000FC;
    IOSET0=0X00000004;
    IOSET0=N;
    IOSET0=0X08;
    delay(20);
    IOCLR0=0X08;
    m=a;
    m=m&0x0f;
    m=m<<4;
    IOCLR0=0XFC;
    IOSET0=0X4;
    IOSET0=M;
    IOSET0=0X8;
    DELAY(20);
    IOCLR0=0X8;
}
void delay(unsigned int z)
{
    unsigned int g,l;
    for(g=0;g<z;g++)
    {
        for(l=0;l<35;l++);
    }
}
