#include<stdio.h>

int main()
{
    int arr[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    char arr1[]="abcdefghijk";
    for(int i=0;i<6;i++)
    printf("%ld ",arr1[i]);
    return 0;
}
