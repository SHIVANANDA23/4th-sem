#include <stdio.h>

int main() {
    register unsigned int ecx;

    for (ecx = 0; ecx < 10; ecx++) {
        printf("Iteration %u\n", ecx);
    }

    return 0;
}
