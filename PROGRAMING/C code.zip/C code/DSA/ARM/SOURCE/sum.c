//Sum of n numbers by register
#include<stdio.h>
#define f 100
#define l 102
int Sum()
{
    register int i=0,s=0;

    for(i=f;i<=l;i++)
    {
        s=s+i;
    }
 return s;

}
int main()
{
   register int s;
    s=Sum();
    printf("Sum from %d to %d numbers is %d",f,l,s);
    return 0;
}
