#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *link;
};
typedef struct node *N;
N insert(N head,int n);
int main()
{
  N head=NULL;
  head=insert(head,10);

}
N insert(N head,int n)
{
    N newnode=malloc(sizeof(struct node));
    if(newnode==NULL)
    {
        printf("NODE IS NOT CREATED\n");
        exit (0);
    }
    newnode->data=n;
    if(head==NULL)
    {
       head= newnode;
    }
    printf("%d",head->data);
}
