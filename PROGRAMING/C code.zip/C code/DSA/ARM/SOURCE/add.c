//Sum of entered numbers by pass by value
#include<stdio.h>
int add(int sum)
{
    int n;
    printf("Enter the numbers\n");
    while(scanf("%d",&n))
    {
       sum+=n;
    }
    return sum;
}
int main()
{
    int sum=0;
    sum=add(sum);/|
    printf("Sum of entered number is %d\n",sum);
    return 0;
}
