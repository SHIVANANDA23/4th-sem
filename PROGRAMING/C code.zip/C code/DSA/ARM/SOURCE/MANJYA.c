#include<stdio.h>
int main()
{
    int a;
    char arr[100];
    FILE* fp=fopen("shiva.txt","r"),*fp2=fopen("manu.txt","r+");
    fscanf(fp,"%d",&a);
    fprintf(fp2,"\na=%d",a);
    rewind(fp2);
    fscanf(fp2,"%s",arr);
    printf("%s",arr);
}
