#include<stdio.h>
//C code for pass by value
void prnt(int a[],int n)
{
    for( int i=0; i<n;i++ )
    {
        printf(" %d ",a[i]);

    }
}
int main()
{
    int a[]={1,10,10,12,5,8,9,8,7,0};
    int n=sizeof(a)/sizeof(a[0]);
    prnt(a,n);
    return 0;
}


