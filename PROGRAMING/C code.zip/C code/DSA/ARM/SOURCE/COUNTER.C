#include<stdio.h>
#include<string.h>
void revers(char str[100])
{
    int r0=0,i=0;
    char temp;

    while(str[r0]!='\0')
    {
        r0++;
    }
    int y=r0/2;
    r0--;
    while((i)!=y)
    {
        temp=str[r0];
        str[r0]=str[i];
        str[i]=temp;
        i++;
        r0--;
    }

}
int main()
{
    char str[100];
    printf("Enter the string to be reversed\n");
    gets(str);
    revers(str);
    printf("The reversed string is %s -",str);
    return 0;
}
