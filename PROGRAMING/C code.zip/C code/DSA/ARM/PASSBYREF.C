#include<stdio.h>
//C code for pass by reference
void prnt(int* p,int* q)
{
    for( int i=0; i<*q;i++ )
    {
        printf(" %d ",*p);
        p++;
    }
}
int main()
{
    int* p,*q;
    int a[]={1,10,10,12,5,8,9,8,7,0};
    int n=sizeof(a)/sizeof(a[0]);
    q=&n;p=a;
    prnt(p,q);
    return 0;
}

