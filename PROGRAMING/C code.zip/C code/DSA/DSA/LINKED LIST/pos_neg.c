#include<stdio.h>
#include<stdlib.h>
#include<time.h>
struct node
{
    int data;
    struct node* next;
};
typedef struct node* NODE;
NODE createNode(int num);
NODE createNode(int num)
{
    NODE newnode;
    newnode=malloc(sizeof(struct node));
    newnode->next=NULL;
    newnode->data=num;
    return newnode;
}
NODE insertEnd(NODE head,int num)
{
    NODE newnode,cur;
    newnode=createNode(num);
    if(head==NULL)
        {
            head=newnode;
        }
    else
        {
            cur=head;
            while(cur->next!=NULL)
                {
                    cur=cur->next;
                }
            cur->next=newnode;
        }
    return head;
}
void display(NODE head)
{
    NODE cur=head;
    if(head==NULL)
        {
            printf("Linked list is empty\n");
        }
    else
        {
            cur=head;
            while(cur!=NULL)
                {
                    printf("%d=",cur);
                    printf("%d ->",cur->data);
                    cur=cur->next;
                }
        }
}
void solve(NODE head,NODE h1,NODE h2)
{
    NODE cur=head;
    while(cur!=NULL)
        {
            if(cur->data>=0)
                {
                    h1=insertEnd(h1,cur->data);
                }
            else
                {
                    h2=insertEnd(h2,cur->data);
                }
            cur=cur->next;
        }
    printf("\nLinked list with positive numbers are \n\n\n");
    display(h1);
    printf("\nLinked list with negative numbers are \n\n\n");
    display(h2);
}
int main()
{
    NODE head=NULL,h1=NULL,h2=NULL;
    int num;
    FILE *fp=NULL;
    fp=fopen("read.txt","r");
    rewind(fp);
    for(int i=0; i<10; i++)
        {
            fscanf(fp,"%d",&num);
            head=insertEnd(head,num);
        }
    printf("Initial Linked list elements are \n");
    display(head);
    solve(head,h1,h2);
}
