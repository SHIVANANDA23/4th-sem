#include<stdio.h>
int main()
{

    char temp,c[100][100];
    FILE* fptr;
    fptr=fopen("arr1.txt","r");
    for(int i=0;i<2;i++)
    fgets(c[i],1000,fptr);
    for(int i=0;i<2;i++)
    printf("%s",c[i]);
    fclose(fptr);
    FILE* f1ptr;
    f1ptr=fopen("arr1.txt","a");
    fprintf(f1ptr,"\nMYNAME IS PR");
    fscanf(f1ptr,"%s",c[1]);
    printf("%s",c[1]);
    fclose(f1ptr);
}
