#include<stdio.h>
int main()
{
    printf("gfgh");
}