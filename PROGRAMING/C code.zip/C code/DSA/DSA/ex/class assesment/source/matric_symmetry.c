#include<stdio.h>

int main()
{
   int n,m;
   printf("ENTER THE ROW AND COLUMN OF MATRIX ");
   scanf("%d %d",&n,&m);
   if (n!=m)
   {
       printf("The row is not equal to column hence we cant determine the Symmetry\n");
       return 0;
   }
   if(n==1||m==1)
   {
       printf("The matrix is symmetric\n");
       return 0;
   }
   int arr[n][m],k=0,c=0;
   printf("Enter the array elements\n");
   for( int i=0;i<n ;i++ )
   {
       for(int j=0;j<n ;j++ )
       {
           scanf("%d",&arr[i][j]);
       }
   }
   for( int i=0;i<n ;i++ )
   {
       for(int j=0;j<n ;j++ )
       {
           if(i!=j)
           {
               c++;
               if(arr[i][j]==arr[j][i])
               {
                  k++;
               }
           }
       }
   }
   if(k==c)
   {
       printf("The matrix is symmetric\n");
   }
   else
     printf("The matrix is not symmetric\n");

    return 0;
}
