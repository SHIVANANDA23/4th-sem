#include<stdio.h>
int x;
int main()
{
    int arr[20],y,arr3[1000],arr4[1000];
    FILE* fp=fopen("arr11.txt","r");
    for(int i=0; i<20; i++)
        {
            fscanf(fp,"%d",&arr[i]);
        }
    for(int i=0; i<20; i++)
        {
            y=arr[i];
            while(y!=0)
                {
                    arr3[x]=y%10;
                    y=y/10;
                    x++;
                }
        }
    for(int i=0; i<x; i++)
        printf("  %d  ",arr3[i]);
    int z=x;
    int j=0,f=0;
    for(int m=0; m<x; m++)
        {
            if(arr3[j]==-1)
                continue;
            for(int i=j; i<x; i++)
                {
                    if(arr3[j]==arr3[i+1])
                        {
                            arr3[i+1]=-1;
                            arr4[i]=-1;
                        }
                }
                 printf(" j=%d ",j);
            for( int i=0; i<x ; i++ )
                {
                    if(arr4[i]==-1)
                        {
                            f++;
                        }
                }
            printf("\n%d is occured %d times",arr3[j],f+1);
            for( int i=0; i<x; i++ )
                {
                    arr4[i]=0;
                }
            j++;
            f=0;
        }
    return 0;
}




