#include<stdio.h>
int chess[8][8]={0};
void move1(int mov,int a,int b,int x,int m,int n)
{
    printf(" kl=%d  y=%d \n",a,b);
    if(mov<1||mov>64)
    {
        printf("THE MOVE RANJE IS 1 - 64\n");
        return;
    }
    else if(chess[a][b]==0)
    {
        chess[m][n]=0;
        chess[a-1][b-1]=x;

    }
}
int enter()
{
    int j=0;
    printf("Enter the paan to be searched\n");
    scanf("%d",&j);
    if(j<17&&j>-17)
    return j;
    else{
        printf("Invalid number please check once again\n");
    }
}
void find(int c)
{
int i,j,pos1=0,pos2=0;
    for(i=0;i<8;i++)
    {
        for(j=0;j<8;j++)
        {
                printf("%d\t",chess[i][j]);

            if(chess[i][j]==c)
            {
               pos1=i;pos2=j;

            }
        }
        printf("\n");

    }
    i=pos1;j=pos2;
   if(c>0)
    {
        if(c==1)
            printf("White elephent_1 is at position %d %d\n",i+1,j+1);
       else if(c==2)
            printf("White horse_1 is at position %d %d\n",i+1,j+1);
       else if(c==3)
            printf("White camel_1 is at position %d %d\n",i+1,j+1);
       else if(c==4)
            printf("White king is at position %d %d\n",i+1,j+1);
       else if(c==5)
            printf("White queen is at position %d %d\n",i+1,j+1);
       else if(c==6)
            printf("White camel_2 is at position %d %d\n",i+1,j+1);
       else if(c==7)
            printf("White horse_2 is at position %d %d\n",i+1,j+1);
       else if(c==8)
            printf("White elephent_2 is at position %d %d\n",i+1,j+1);
       else if(c==9)
            printf("White  solder1 is at position %d %d\n",i+1,j+1);
       else if(c==10)
            printf("White   solder2 is at position %d %d\n",i+1,j+1);
       else if(c==11)
            printf("White  solder3 is at position %d %d\n",i+1,j+1);
       else if(c==12)
            printf("White  solder4 is at position %d %d\n",i+1,j+1);
        else if(c==13)
            printf("White  solder5 is at position %d %d\n",i+1,j+1);
        else if(c==14)
            printf("White  solder6 is at position %d %d\n",i+1,j+1);
        else if(c==15)
            printf("White  solder7 is at position %d %d\n",i+1,j+1);
        else if(c==16)
            printf("White  solder8 is at position %d %d\n",i+1,j+1);
    }

    else if(c<0)
    {
        if(c==-1)
            printf("Black elephent_1 is at position %d %d\n",i+1,j+1);
       else if(c==-2)
            printf("Black horse_1 is at position %d %d\n",i+1,j+1);
        else if(c==-3)
            printf("Black camel_1 is at position %d %d\n",i+1,j+1);
       else if(c==-4)
            printf("Black king is at position %d %d\n",i+1,j+1);
       else if(c==-5)
            printf("Black queen is at position %d %d\n",i+1,j+1);
       else if(c==-6)
            printf("Black camel_2 is at position %d %d\n",i+1,j+1);
       else if(c==-7)
            printf("Black horse_2 is at position %d %d\n",i+1,j+1);
       else if(c==-8)
            printf("Black elephent_2 is at position %d %d\n",i+1,j+1);
       else if(c==-9)
            printf("Black  solder1 is at position %d %d\n",i+1,j+1);
       else if(c==-10)
            printf("Black   solder2 is at position %d %d\n",i+1,j+1);
       else if(c==-11)
            printf("Black  solder3 is at position %d %d\n",i+1,j+1);
       else if(c==-12)
            printf("Black  solder4 is at position %d %d\n",i+1,j+1);
        else if(c==-13)
            printf("Black  solder5 is at position %d %d\n",i+1,j+1);
        else if(c==-14)
            printf("Black solder6 is at position %d %d\n",i+1,j+1);
        else if(c==-15)
            printf("Black  solder7 is at position %d %d\n",i+1,j+1);
        else if(c==-16)
            printf("Black  solder8 is at position %d %d\n",i+1,j+1);
    }

}
int main()
{

  int x,k=0,m,n,temp=0,mov=0,pos1=0,pos2=0,l=0,kl=0,y=0;
  char c,z;
  printf("Enter \n 1 for W_E_1 \n 2 for W_H_1 \n 3 for W_C_1 \n 4 for W_Q \n 5 for W_K \n 6 for W_C_1 \n 7 for W_H_1 \n 8 for W_E_1 \n 9-16 for resp solders\n\n SAME In negetive for BLACK\n");

  for (int i=0;i<2;i++)
  {
      for(int j=0;j<8;j++)
      {
          if(i==1)
          {
          chess[i][j]=j+9;
          }

          else
            chess[i][j]=j+1;
      }
  }
  for (int i=7;i>5;i--)
  {
      for(int j=0;j<8;j++)
      {
          if(i==6)
          chess[i][j]=-(j+9);
          else
            chess[i][j]=-(j+1);
      }
  }
 while(c!='n')
 {
     x=enter();
        for(m=0;m<8;m++)
    {
        for(n=0;n<8;n++)
        {
            if(chess[m][n]==x)
            {
               pos1=m;pos2=n;
            }
        }
    }
    m=pos1;n=pos2;
     find(x);
     printf("do you want to move paan\n");
     scanf(" %c",&z);

         if(z!='n'&&z!='N')
         {
             printf("\nENTER THE POSITION\n");
             scanf("%d",&mov);
             temp=mov;
             y=mov;
             y=y%8;
             if(y==0)
             {
                 y=8;
                 kl=mov/8;
             }
             else{
                kl=(mov/8)+1;
             }
             printf(" kl=%d  y=%d \n",kl,y);
              move1(temp,kl,y,x,m,n);
           }
           printf("\nDo You Want To Continue IF yes press Y else N\n");
           scanf(" %c",&c);
         }
 }

