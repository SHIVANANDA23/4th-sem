#include<stdio.h>

struct node
{
    int data;
    struct node* link;

};
typedef struct node* N;

int main()
{
    N head=null;
    printf("OPERATIONS\n");
    while(1)
    {
        int x;
        printf("ENTER THE CHOICE\n");
        scanf("%d",&x);
        switch(x)
    case 1:
          head=insert
    }
    return 0;
}
